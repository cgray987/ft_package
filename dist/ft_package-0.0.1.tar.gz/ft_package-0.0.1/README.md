# This is an example python package created to understand how python packaging works.

Using Hatchling to upload to PyPi.

Functions:
├── banana_size.py
├── count_in_list.py
├── duck_translate.py
└── morse_translate.py